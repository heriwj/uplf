document.getElementById("refreshBtn").addEventListener("click", generate);
//document.getElementById("btn").addEventListener("click", printmsg);
let captcha;  // Declare the captcha variable

// Function to generate a new CAPTCHA
function generate() {
    // Clear the previous input value
    document.getElementById("captchatxt").value = "";

    // Access the element where captcha will be displayed
    captcha = document.getElementById("image");

    let uniquechar = "";
    const randomchar = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";

    // Generate a 5-character random captcha
    for (let i = 0; i < 5; i++) {
        uniquechar += randomchar.charAt(Math.floor(Math.random() * randomchar.length));
    }

    // Store the generated captcha in the image div
    captcha.innerHTML = uniquechar;
}

// Function to validate the user input
function printmsg() {
    const usr_input = document.getElementById("captchatxt").value; // Get user input

    // Check whether the user input matches the generated captcha
    if (usr_input === captcha.innerHTML) {
        document.getElementById("key").innerHTML = "Captcha Matched!"; // Feedback message
        document.getElementById("key").style.color = "green"; // Change feedback color to green
        document.getElementById("key").style.fontSize = "small";
        document.getElementById("viewStatement").removeAttribute('disabled');
        // generate(); // Generate a new captcha
    } else {
        document.getElementById("key").innerHTML = "Captcha Not Matched!"; // Feedback message
        document.getElementById("key").style.color = "red"; // Change feedback color to red
         document.getElementById("key").style.fontSize = "small";
        generate(); // Generate a new captcha
    }
}
