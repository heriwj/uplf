/* 
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/JavaScript.js to edit this template
 */


document.getElementById("refreshBtn").addEventListener("click", refreshCaptcha);

$(document).ready(function () {

    $("#viewStatement").click(function (event) {
        event.preventDefault(); // Prevent default form submission
        let form = $("#login-form");
        var pwd = document.getElementById("password").value;
        const usr_input = document.getElementById("captchatxt").value; // Get user input
        if (pwd.trim().length < 6) {
            document.getElementById("errorMessage").innerHTML = "Please Enter Correct Password ";
            document.getElementById("password").value = "";
         
            return false;
        }
        if (usr_input.length === 0) {
            document.getElementById("errorMessage").innerHTML = "Captcha is Empty! Try Again";
            document.getElementById("password").value = "";
            return false;
        }


        if (usr_input !== 0 && pwd.trim().length !== 0) {
            document.getElementById("errorMessage").innerHTML = "";
            document.getElementById("key").innerHTML = "";
            form.submit();
        }
    });
});

function refreshCaptcha() {
    $.get("refreshcaptcha", function (result) {
        $("#captchadiv").attr('src', "");
        $("#captchadiv").attr('src', "data:image/png;base64," + result + "");
    });
}