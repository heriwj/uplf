/**
 * SecurityHolders.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package routines;

public class SecurityHolders  extends routines.Common  implements java.io.Serializable {
    private routines.Security security;

    private routines.Holder[] holders;

    public SecurityHolders() {
    }

    public SecurityHolders(
           routines.OutcomeTypes outcome,
           java.lang.String message,
           java.lang.String identity,
           double delay,
           routines.Security security,
           routines.Holder[] holders) {
        super(
            outcome,
            message,
            identity,
            delay);
        this.security = security;
        this.holders = holders;
    }


    /**
     * Gets the security value for this SecurityHolders.
     * 
     * @return security
     */
    public routines.Security getSecurity() {
        return security;
    }


    /**
     * Sets the security value for this SecurityHolders.
     * 
     * @param security
     */
    public void setSecurity(routines.Security security) {
        this.security = security;
    }


    /**
     * Gets the holders value for this SecurityHolders.
     * 
     * @return holders
     */
    public routines.Holder[] getHolders() {
        return holders;
    }


    /**
     * Sets the holders value for this SecurityHolders.
     * 
     * @param holders
     */
    public void setHolders(routines.Holder[] holders) {
        this.holders = holders;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof SecurityHolders)) return false;
        SecurityHolders other = (SecurityHolders) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = super.equals(obj) && 
            ((this.security==null && other.getSecurity()==null) || 
             (this.security!=null &&
              this.security.equals(other.getSecurity()))) &&
            ((this.holders==null && other.getHolders()==null) || 
             (this.holders!=null &&
              java.util.Arrays.equals(this.holders, other.getHolders())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = super.hashCode();
        if (getSecurity() != null) {
            _hashCode += getSecurity().hashCode();
        }
        if (getHolders() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getHolders());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getHolders(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(SecurityHolders.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://www.xignite.com/services/", "SecurityHolders"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("security");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.xignite.com/services/", "Security"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.xignite.com/services/", "Security"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("holders");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.xignite.com/services/", "Holders"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.xignite.com/services/", "Holder"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        elemField.setItemQName(new javax.xml.namespace.QName("http://www.xignite.com/services/", "Holder"));
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
