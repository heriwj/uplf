/**
 * XigniteFundHoldings.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package routines;

public interface XigniteFundHoldings extends javax.xml.rpc.Service {

/**
 * this web service provides information about mutual funds holdings.
 */
    public java.lang.String getXigniteFundHoldingsSoapAddress();

    public routines.XigniteFundHoldingsSoap_PortType getXigniteFundHoldingsSoap() throws javax.xml.rpc.ServiceException;

    public routines.XigniteFundHoldingsSoap_PortType getXigniteFundHoldingsSoap(java.net.URL portAddress) throws javax.xml.rpc.ServiceException;
    public java.lang.String getXigniteFundHoldingsSoap12Address();

    public routines.XigniteFundHoldingsSoap_PortType getXigniteFundHoldingsSoap12() throws javax.xml.rpc.ServiceException;

    public routines.XigniteFundHoldingsSoap_PortType getXigniteFundHoldingsSoap12(java.net.URL portAddress) throws javax.xml.rpc.ServiceException;
}
