/**
 * ShortFiling.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package routines;

public class ShortFiling  extends routines.Common  implements java.io.Serializable {
    private java.lang.String CIK;

    private java.lang.String date;

    private java.lang.String type;

    private boolean amendment;

    private java.lang.String textFileUrl;

    private java.lang.String htmlFileUrl;

    private java.lang.String alternateHtmlFileUrl;

    private int filingId;

    public ShortFiling() {
    }

    public ShortFiling(
           routines.OutcomeTypes outcome,
           java.lang.String message,
           java.lang.String identity,
           double delay,
           java.lang.String CIK,
           java.lang.String date,
           java.lang.String type,
           boolean amendment,
           java.lang.String textFileUrl,
           java.lang.String htmlFileUrl,
           java.lang.String alternateHtmlFileUrl,
           int filingId) {
        super(
            outcome,
            message,
            identity,
            delay);
        this.CIK = CIK;
        this.date = date;
        this.type = type;
        this.amendment = amendment;
        this.textFileUrl = textFileUrl;
        this.htmlFileUrl = htmlFileUrl;
        this.alternateHtmlFileUrl = alternateHtmlFileUrl;
        this.filingId = filingId;
    }


    /**
     * Gets the CIK value for this ShortFiling.
     * 
     * @return CIK
     */
    public java.lang.String getCIK() {
        return CIK;
    }


    /**
     * Sets the CIK value for this ShortFiling.
     * 
     * @param CIK
     */
    public void setCIK(java.lang.String CIK) {
        this.CIK = CIK;
    }


    /**
     * Gets the date value for this ShortFiling.
     * 
     * @return date
     */
    public java.lang.String getDate() {
        return date;
    }


    /**
     * Sets the date value for this ShortFiling.
     * 
     * @param date
     */
    public void setDate(java.lang.String date) {
        this.date = date;
    }


    /**
     * Gets the type value for this ShortFiling.
     * 
     * @return type
     */
    public java.lang.String getType() {
        return type;
    }


    /**
     * Sets the type value for this ShortFiling.
     * 
     * @param type
     */
    public void setType(java.lang.String type) {
        this.type = type;
    }


    /**
     * Gets the amendment value for this ShortFiling.
     * 
     * @return amendment
     */
    public boolean isAmendment() {
        return amendment;
    }


    /**
     * Sets the amendment value for this ShortFiling.
     * 
     * @param amendment
     */
    public void setAmendment(boolean amendment) {
        this.amendment = amendment;
    }


    /**
     * Gets the textFileUrl value for this ShortFiling.
     * 
     * @return textFileUrl
     */
    public java.lang.String getTextFileUrl() {
        return textFileUrl;
    }


    /**
     * Sets the textFileUrl value for this ShortFiling.
     * 
     * @param textFileUrl
     */
    public void setTextFileUrl(java.lang.String textFileUrl) {
        this.textFileUrl = textFileUrl;
    }


    /**
     * Gets the htmlFileUrl value for this ShortFiling.
     * 
     * @return htmlFileUrl
     */
    public java.lang.String getHtmlFileUrl() {
        return htmlFileUrl;
    }


    /**
     * Sets the htmlFileUrl value for this ShortFiling.
     * 
     * @param htmlFileUrl
     */
    public void setHtmlFileUrl(java.lang.String htmlFileUrl) {
        this.htmlFileUrl = htmlFileUrl;
    }


    /**
     * Gets the alternateHtmlFileUrl value for this ShortFiling.
     * 
     * @return alternateHtmlFileUrl
     */
    public java.lang.String getAlternateHtmlFileUrl() {
        return alternateHtmlFileUrl;
    }


    /**
     * Sets the alternateHtmlFileUrl value for this ShortFiling.
     * 
     * @param alternateHtmlFileUrl
     */
    public void setAlternateHtmlFileUrl(java.lang.String alternateHtmlFileUrl) {
        this.alternateHtmlFileUrl = alternateHtmlFileUrl;
    }


    /**
     * Gets the filingId value for this ShortFiling.
     * 
     * @return filingId
     */
    public int getFilingId() {
        return filingId;
    }


    /**
     * Sets the filingId value for this ShortFiling.
     * 
     * @param filingId
     */
    public void setFilingId(int filingId) {
        this.filingId = filingId;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof ShortFiling)) return false;
        ShortFiling other = (ShortFiling) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = super.equals(obj) && 
            ((this.CIK==null && other.getCIK()==null) || 
             (this.CIK!=null &&
              this.CIK.equals(other.getCIK()))) &&
            ((this.date==null && other.getDate()==null) || 
             (this.date!=null &&
              this.date.equals(other.getDate()))) &&
            ((this.type==null && other.getType()==null) || 
             (this.type!=null &&
              this.type.equals(other.getType()))) &&
            this.amendment == other.isAmendment() &&
            ((this.textFileUrl==null && other.getTextFileUrl()==null) || 
             (this.textFileUrl!=null &&
              this.textFileUrl.equals(other.getTextFileUrl()))) &&
            ((this.htmlFileUrl==null && other.getHtmlFileUrl()==null) || 
             (this.htmlFileUrl!=null &&
              this.htmlFileUrl.equals(other.getHtmlFileUrl()))) &&
            ((this.alternateHtmlFileUrl==null && other.getAlternateHtmlFileUrl()==null) || 
             (this.alternateHtmlFileUrl!=null &&
              this.alternateHtmlFileUrl.equals(other.getAlternateHtmlFileUrl()))) &&
            this.filingId == other.getFilingId();
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = super.hashCode();
        if (getCIK() != null) {
            _hashCode += getCIK().hashCode();
        }
        if (getDate() != null) {
            _hashCode += getDate().hashCode();
        }
        if (getType() != null) {
            _hashCode += getType().hashCode();
        }
        _hashCode += (isAmendment() ? Boolean.TRUE : Boolean.FALSE).hashCode();
        if (getTextFileUrl() != null) {
            _hashCode += getTextFileUrl().hashCode();
        }
        if (getHtmlFileUrl() != null) {
            _hashCode += getHtmlFileUrl().hashCode();
        }
        if (getAlternateHtmlFileUrl() != null) {
            _hashCode += getAlternateHtmlFileUrl().hashCode();
        }
        _hashCode += getFilingId();
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(ShortFiling.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://www.xignite.com/services/", "ShortFiling"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("CIK");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.xignite.com/services/", "CIK"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("date");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.xignite.com/services/", "Date"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("type");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.xignite.com/services/", "Type"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("amendment");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.xignite.com/services/", "Amendment"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("textFileUrl");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.xignite.com/services/", "TextFileUrl"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("htmlFileUrl");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.xignite.com/services/", "HtmlFileUrl"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("alternateHtmlFileUrl");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.xignite.com/services/", "AlternateHtmlFileUrl"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("filingId");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.xignite.com/services/", "FilingId"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
