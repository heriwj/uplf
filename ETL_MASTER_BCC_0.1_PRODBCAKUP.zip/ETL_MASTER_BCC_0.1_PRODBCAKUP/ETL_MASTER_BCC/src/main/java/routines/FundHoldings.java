/**
 * FundHoldings.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package routines;

public class FundHoldings  extends routines.Common  implements java.io.Serializable {
    private routines.Fund fund;

    private routines.ShortFiling filing;

    private routines.Holding[] holdings;

    public FundHoldings() {
    }

    public FundHoldings(
           routines.OutcomeTypes outcome,
           java.lang.String message,
           java.lang.String identity,
           double delay,
           routines.Fund fund,
           routines.ShortFiling filing,
           routines.Holding[] holdings) {
        super(
            outcome,
            message,
            identity,
            delay);
        this.fund = fund;
        this.filing = filing;
        this.holdings = holdings;
    }


    /**
     * Gets the fund value for this FundHoldings.
     * 
     * @return fund
     */
    public routines.Fund getFund() {
        return fund;
    }


    /**
     * Sets the fund value for this FundHoldings.
     * 
     * @param fund
     */
    public void setFund(routines.Fund fund) {
        this.fund = fund;
    }


    /**
     * Gets the filing value for this FundHoldings.
     * 
     * @return filing
     */
    public routines.ShortFiling getFiling() {
        return filing;
    }


    /**
     * Sets the filing value for this FundHoldings.
     * 
     * @param filing
     */
    public void setFiling(routines.ShortFiling filing) {
        this.filing = filing;
    }


    /**
     * Gets the holdings value for this FundHoldings.
     * 
     * @return holdings
     */
    public routines.Holding[] getHoldings() {
        return holdings;
    }


    /**
     * Sets the holdings value for this FundHoldings.
     * 
     * @param holdings
     */
    public void setHoldings(routines.Holding[] holdings) {
        this.holdings = holdings;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof FundHoldings)) return false;
        FundHoldings other = (FundHoldings) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = super.equals(obj) && 
            ((this.fund==null && other.getFund()==null) || 
             (this.fund!=null &&
              this.fund.equals(other.getFund()))) &&
            ((this.filing==null && other.getFiling()==null) || 
             (this.filing!=null &&
              this.filing.equals(other.getFiling()))) &&
            ((this.holdings==null && other.getHoldings()==null) || 
             (this.holdings!=null &&
              java.util.Arrays.equals(this.holdings, other.getHoldings())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = super.hashCode();
        if (getFund() != null) {
            _hashCode += getFund().hashCode();
        }
        if (getFiling() != null) {
            _hashCode += getFiling().hashCode();
        }
        if (getHoldings() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getHoldings());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getHoldings(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(FundHoldings.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://www.xignite.com/services/", "FundHoldings"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("fund");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.xignite.com/services/", "Fund"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.xignite.com/services/", "Fund"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("filing");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.xignite.com/services/", "Filing"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.xignite.com/services/", "ShortFiling"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("holdings");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.xignite.com/services/", "Holdings"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.xignite.com/services/", "Holding"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        elemField.setItemQName(new javax.xml.namespace.QName("http://www.xignite.com/services/", "Holding"));
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
