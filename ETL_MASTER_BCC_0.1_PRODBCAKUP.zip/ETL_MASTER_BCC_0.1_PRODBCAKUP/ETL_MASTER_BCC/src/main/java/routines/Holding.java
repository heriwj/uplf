/**
 * Holding.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package routines;

public class Holding  implements java.io.Serializable {
    private routines.Security security;

    private double value;

    private double shares;

    private double change;

    private double percentOfFund;

    private double YTDReturn;

    public Holding() {
    }

    public Holding(
           routines.Security security,
           double value,
           double shares,
           double change,
           double percentOfFund,
           double YTDReturn) {
           this.security = security;
           this.value = value;
           this.shares = shares;
           this.change = change;
           this.percentOfFund = percentOfFund;
           this.YTDReturn = YTDReturn;
    }


    /**
     * Gets the security value for this Holding.
     * 
     * @return security
     */
    public routines.Security getSecurity() {
        return security;
    }


    /**
     * Sets the security value for this Holding.
     * 
     * @param security
     */
    public void setSecurity(routines.Security security) {
        this.security = security;
    }


    /**
     * Gets the value value for this Holding.
     * 
     * @return value
     */
    public double getValue() {
        return value;
    }


    /**
     * Sets the value value for this Holding.
     * 
     * @param value
     */
    public void setValue(double value) {
        this.value = value;
    }


    /**
     * Gets the shares value for this Holding.
     * 
     * @return shares
     */
    public double getShares() {
        return shares;
    }


    /**
     * Sets the shares value for this Holding.
     * 
     * @param shares
     */
    public void setShares(double shares) {
        this.shares = shares;
    }


    /**
     * Gets the change value for this Holding.
     * 
     * @return change
     */
    public double getChange() {
        return change;
    }


    /**
     * Sets the change value for this Holding.
     * 
     * @param change
     */
    public void setChange(double change) {
        this.change = change;
    }


    /**
     * Gets the percentOfFund value for this Holding.
     * 
     * @return percentOfFund
     */
    public double getPercentOfFund() {
        return percentOfFund;
    }


    /**
     * Sets the percentOfFund value for this Holding.
     * 
     * @param percentOfFund
     */
    public void setPercentOfFund(double percentOfFund) {
        this.percentOfFund = percentOfFund;
    }


    /**
     * Gets the YTDReturn value for this Holding.
     * 
     * @return YTDReturn
     */
    public double getYTDReturn() {
        return YTDReturn;
    }


    /**
     * Sets the YTDReturn value for this Holding.
     * 
     * @param YTDReturn
     */
    public void setYTDReturn(double YTDReturn) {
        this.YTDReturn = YTDReturn;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof Holding)) return false;
        Holding other = (Holding) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.security==null && other.getSecurity()==null) || 
             (this.security!=null &&
              this.security.equals(other.getSecurity()))) &&
            this.value == other.getValue() &&
            this.shares == other.getShares() &&
            this.change == other.getChange() &&
            this.percentOfFund == other.getPercentOfFund() &&
            this.YTDReturn == other.getYTDReturn();
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getSecurity() != null) {
            _hashCode += getSecurity().hashCode();
        }
        _hashCode += new Double(getValue()).hashCode();
        _hashCode += new Double(getShares()).hashCode();
        _hashCode += new Double(getChange()).hashCode();
        _hashCode += new Double(getPercentOfFund()).hashCode();
        _hashCode += new Double(getYTDReturn()).hashCode();
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(Holding.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://www.xignite.com/services/", "Holding"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("security");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.xignite.com/services/", "Security"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.xignite.com/services/", "Security"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("value");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.xignite.com/services/", "Value"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "double"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("shares");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.xignite.com/services/", "Shares"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "double"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("change");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.xignite.com/services/", "Change"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "double"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("percentOfFund");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.xignite.com/services/", "PercentOfFund"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "double"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("YTDReturn");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.xignite.com/services/", "YTDReturn"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "double"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
