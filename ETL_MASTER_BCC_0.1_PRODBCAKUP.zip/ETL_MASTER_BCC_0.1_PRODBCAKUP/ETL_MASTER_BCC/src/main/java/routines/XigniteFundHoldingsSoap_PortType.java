/**
 * XigniteFundHoldingsSoap_PortType.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package routines;

public interface XigniteFundHoldingsSoap_PortType extends java.rmi.Remote {

    /**
     * Lookup a fund by name.
     */
    public routines.Fund[] lookupFund(java.lang.String name) throws java.rmi.RemoteException;

    /**
     * Lists all funds by symbol.
     */
    public routines.Fund[] listFunds(java.lang.String startSymbol, java.lang.String endSymbol) throws java.rmi.RemoteException;

    /**
     * Returns latest holding information for a fund.
     */
    public routines.FundHoldings getLatestHoldings(java.lang.String identifier, routines.IdentifierTypes identifierType, int count) throws java.rmi.RemoteException;

    /**
     * Returns holdings by order of increasing position.
     */
    public routines.FundHoldings getIncreasedHoldings(java.lang.String identifier, routines.IdentifierTypes identifierType, int count) throws java.rmi.RemoteException;

    /**
     * Returns latest top holding information for a fund.
     */
    public routines.FundHoldings getTopHoldings(java.lang.String identifier, routines.IdentifierTypes identifierType, routines.TopTypes topType) throws java.rmi.RemoteException;

    /**
     * Returns latest holder information for a security.
     */
    public routines.SecurityHolders getLatestHolders(java.lang.String identifier, routines.IdentifierTypes identifierType, int count) throws java.rmi.RemoteException;

    /**
     * Returns holders by order of increasing position.
     */
    public routines.SecurityHolders getIncreasedHolders(java.lang.String identifier, routines.IdentifierTypes identifierType, int count) throws java.rmi.RemoteException;

    /**
     * Returns latest top holder information for a security.
     */
    public routines.SecurityHolders getTopHolders(java.lang.String identifier, routines.IdentifierTypes identifierType, routines.TopTypes topType) throws java.rmi.RemoteException;
}
