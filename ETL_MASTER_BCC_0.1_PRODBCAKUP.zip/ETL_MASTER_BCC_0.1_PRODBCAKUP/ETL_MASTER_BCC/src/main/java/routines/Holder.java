/**
 * Holder.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package routines;

public class Holder  implements java.io.Serializable {
    private routines.Fund fund;

    private java.lang.String asOfDate;

    private double value;

    private double shares;

    private double change;

    private double percentofShares;

    public Holder() {
    }

    public Holder(
           routines.Fund fund,
           java.lang.String asOfDate,
           double value,
           double shares,
           double change,
           double percentofShares) {
           this.fund = fund;
           this.asOfDate = asOfDate;
           this.value = value;
           this.shares = shares;
           this.change = change;
           this.percentofShares = percentofShares;
    }


    /**
     * Gets the fund value for this Holder.
     * 
     * @return fund
     */
    public routines.Fund getFund() {
        return fund;
    }


    /**
     * Sets the fund value for this Holder.
     * 
     * @param fund
     */
    public void setFund(routines.Fund fund) {
        this.fund = fund;
    }


    /**
     * Gets the asOfDate value for this Holder.
     * 
     * @return asOfDate
     */
    public java.lang.String getAsOfDate() {
        return asOfDate;
    }


    /**
     * Sets the asOfDate value for this Holder.
     * 
     * @param asOfDate
     */
    public void setAsOfDate(java.lang.String asOfDate) {
        this.asOfDate = asOfDate;
    }


    /**
     * Gets the value value for this Holder.
     * 
     * @return value
     */
    public double getValue() {
        return value;
    }


    /**
     * Sets the value value for this Holder.
     * 
     * @param value
     */
    public void setValue(double value) {
        this.value = value;
    }


    /**
     * Gets the shares value for this Holder.
     * 
     * @return shares
     */
    public double getShares() {
        return shares;
    }


    /**
     * Sets the shares value for this Holder.
     * 
     * @param shares
     */
    public void setShares(double shares) {
        this.shares = shares;
    }


    /**
     * Gets the change value for this Holder.
     * 
     * @return change
     */
    public double getChange() {
        return change;
    }


    /**
     * Sets the change value for this Holder.
     * 
     * @param change
     */
    public void setChange(double change) {
        this.change = change;
    }


    /**
     * Gets the percentofShares value for this Holder.
     * 
     * @return percentofShares
     */
    public double getPercentofShares() {
        return percentofShares;
    }


    /**
     * Sets the percentofShares value for this Holder.
     * 
     * @param percentofShares
     */
    public void setPercentofShares(double percentofShares) {
        this.percentofShares = percentofShares;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof Holder)) return false;
        Holder other = (Holder) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.fund==null && other.getFund()==null) || 
             (this.fund!=null &&
              this.fund.equals(other.getFund()))) &&
            ((this.asOfDate==null && other.getAsOfDate()==null) || 
             (this.asOfDate!=null &&
              this.asOfDate.equals(other.getAsOfDate()))) &&
            this.value == other.getValue() &&
            this.shares == other.getShares() &&
            this.change == other.getChange() &&
            this.percentofShares == other.getPercentofShares();
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getFund() != null) {
            _hashCode += getFund().hashCode();
        }
        if (getAsOfDate() != null) {
            _hashCode += getAsOfDate().hashCode();
        }
        _hashCode += new Double(getValue()).hashCode();
        _hashCode += new Double(getShares()).hashCode();
        _hashCode += new Double(getChange()).hashCode();
        _hashCode += new Double(getPercentofShares()).hashCode();
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(Holder.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://www.xignite.com/services/", "Holder"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("fund");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.xignite.com/services/", "Fund"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.xignite.com/services/", "Fund"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("asOfDate");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.xignite.com/services/", "AsOfDate"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("value");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.xignite.com/services/", "Value"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "double"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("shares");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.xignite.com/services/", "Shares"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "double"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("change");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.xignite.com/services/", "Change"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "double"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("percentofShares");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.xignite.com/services/", "PercentofShares"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "double"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
