/**
 * XigniteFundHoldingsLocator.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package routines;

public class XigniteFundHoldingsLocator extends org.apache.axis.client.Service implements routines.XigniteFundHoldings {

/**
 * this web service provides information about mutual funds holdings.
 */

    public XigniteFundHoldingsLocator() {
    }


    public XigniteFundHoldingsLocator(org.apache.axis.EngineConfiguration config) {
        super(config);
    }

    public XigniteFundHoldingsLocator(java.lang.String wsdlLoc, javax.xml.namespace.QName sName) throws javax.xml.rpc.ServiceException {
        super(wsdlLoc, sName);
    }

    // Use to get a proxy class for XigniteFundHoldingsSoap
    private java.lang.String XigniteFundHoldingsSoap_address = "http://www.xignite.com/xFundHoldings.asmx";

    public java.lang.String getXigniteFundHoldingsSoapAddress() {
        return XigniteFundHoldingsSoap_address;
    }

    // The WSDD service name defaults to the port name.
    private java.lang.String XigniteFundHoldingsSoapWSDDServiceName = "XigniteFundHoldingsSoap";

    public java.lang.String getXigniteFundHoldingsSoapWSDDServiceName() {
        return XigniteFundHoldingsSoapWSDDServiceName;
    }

    public void setXigniteFundHoldingsSoapWSDDServiceName(java.lang.String name) {
        XigniteFundHoldingsSoapWSDDServiceName = name;
    }

    public routines.XigniteFundHoldingsSoap_PortType getXigniteFundHoldingsSoap() throws javax.xml.rpc.ServiceException {
       java.net.URL endpoint;
        try {
            endpoint = new java.net.URL(XigniteFundHoldingsSoap_address);
        }
        catch (java.net.MalformedURLException e) {
            throw new javax.xml.rpc.ServiceException(e);
        }
        return getXigniteFundHoldingsSoap(endpoint);
    }

    public routines.XigniteFundHoldingsSoap_PortType getXigniteFundHoldingsSoap(java.net.URL portAddress) throws javax.xml.rpc.ServiceException {
        try {
            routines.XigniteFundHoldingsSoap_BindingStub _stub = new routines.XigniteFundHoldingsSoap_BindingStub(portAddress, this);
            _stub.setPortName(getXigniteFundHoldingsSoapWSDDServiceName());
            return _stub;
        }
        catch (org.apache.axis.AxisFault e) {
            return null;
        }
    }

    public void setXigniteFundHoldingsSoapEndpointAddress(java.lang.String address) {
        XigniteFundHoldingsSoap_address = address;
    }


    // Use to get a proxy class for XigniteFundHoldingsSoap12
    private java.lang.String XigniteFundHoldingsSoap12_address = "http://www.xignite.com/xFundHoldings.asmx";

    public java.lang.String getXigniteFundHoldingsSoap12Address() {
        return XigniteFundHoldingsSoap12_address;
    }

    // The WSDD service name defaults to the port name.
    private java.lang.String XigniteFundHoldingsSoap12WSDDServiceName = "XigniteFundHoldingsSoap12";

    public java.lang.String getXigniteFundHoldingsSoap12WSDDServiceName() {
        return XigniteFundHoldingsSoap12WSDDServiceName;
    }

    public void setXigniteFundHoldingsSoap12WSDDServiceName(java.lang.String name) {
        XigniteFundHoldingsSoap12WSDDServiceName = name;
    }

    public routines.XigniteFundHoldingsSoap_PortType getXigniteFundHoldingsSoap12() throws javax.xml.rpc.ServiceException {
       java.net.URL endpoint;
        try {
            endpoint = new java.net.URL(XigniteFundHoldingsSoap12_address);
        }
        catch (java.net.MalformedURLException e) {
            throw new javax.xml.rpc.ServiceException(e);
        }
        return getXigniteFundHoldingsSoap12(endpoint);
    }

    public routines.XigniteFundHoldingsSoap_PortType getXigniteFundHoldingsSoap12(java.net.URL portAddress) throws javax.xml.rpc.ServiceException {
        try {
            routines.XigniteFundHoldingsSoap12Stub _stub = new routines.XigniteFundHoldingsSoap12Stub(portAddress, this);
            _stub.setPortName(getXigniteFundHoldingsSoap12WSDDServiceName());
            return _stub;
        }
        catch (org.apache.axis.AxisFault e) {
            return null;
        }
    }

    public void setXigniteFundHoldingsSoap12EndpointAddress(java.lang.String address) {
        XigniteFundHoldingsSoap12_address = address;
    }

    /**
     * For the given interface, get the stub implementation.
     * If this service has no port for the given interface,
     * then ServiceException is thrown.
     * This service has multiple ports for a given interface;
     * the proxy implementation returned may be indeterminate.
     */
    public java.rmi.Remote getPort(Class serviceEndpointInterface) throws javax.xml.rpc.ServiceException {
        try {
            if (routines.XigniteFundHoldingsSoap_PortType.class.isAssignableFrom(serviceEndpointInterface)) {
                routines.XigniteFundHoldingsSoap_BindingStub _stub = new routines.XigniteFundHoldingsSoap_BindingStub(new java.net.URL(XigniteFundHoldingsSoap_address), this);
                _stub.setPortName(getXigniteFundHoldingsSoapWSDDServiceName());
                return _stub;
            }
            if (routines.XigniteFundHoldingsSoap_PortType.class.isAssignableFrom(serviceEndpointInterface)) {
                routines.XigniteFundHoldingsSoap12Stub _stub = new routines.XigniteFundHoldingsSoap12Stub(new java.net.URL(XigniteFundHoldingsSoap12_address), this);
                _stub.setPortName(getXigniteFundHoldingsSoap12WSDDServiceName());
                return _stub;
            }
        }
        catch (java.lang.Throwable t) {
            throw new javax.xml.rpc.ServiceException(t);
        }
        throw new javax.xml.rpc.ServiceException("There is no stub implementation for the interface:  " + (serviceEndpointInterface == null ? "null" : serviceEndpointInterface.getName()));
    }

    /**
     * For the given interface, get the stub implementation.
     * If this service has no port for the given interface,
     * then ServiceException is thrown.
     */
    public java.rmi.Remote getPort(javax.xml.namespace.QName portName, Class serviceEndpointInterface) throws javax.xml.rpc.ServiceException {
        if (portName == null) {
            return getPort(serviceEndpointInterface);
        }
        java.lang.String inputPortName = portName.getLocalPart();
        if ("XigniteFundHoldingsSoap".equals(inputPortName)) {
            return getXigniteFundHoldingsSoap();
        }
        else if ("XigniteFundHoldingsSoap12".equals(inputPortName)) {
            return getXigniteFundHoldingsSoap12();
        }
        else  {
            java.rmi.Remote _stub = getPort(serviceEndpointInterface);
            ((org.apache.axis.client.Stub) _stub).setPortName(portName);
            return _stub;
        }
    }

    public javax.xml.namespace.QName getServiceName() {
        return new javax.xml.namespace.QName("http://www.xignite.com/services/", "XigniteFundHoldings");
    }

    private java.util.HashSet ports = null;

    public java.util.Iterator getPorts() {
        if (ports == null) {
            ports = new java.util.HashSet();
            ports.add(new javax.xml.namespace.QName("http://www.xignite.com/services/", "XigniteFundHoldingsSoap"));
            ports.add(new javax.xml.namespace.QName("http://www.xignite.com/services/", "XigniteFundHoldingsSoap12"));
        }
        return ports.iterator();
    }

    /**
    * Set the endpoint address for the specified port name.
    */
    public void setEndpointAddress(java.lang.String portName, java.lang.String address) throws javax.xml.rpc.ServiceException {
        
if ("XigniteFundHoldingsSoap".equals(portName)) {
            setXigniteFundHoldingsSoapEndpointAddress(address);
        }
        else 
if ("XigniteFundHoldingsSoap12".equals(portName)) {
            setXigniteFundHoldingsSoap12EndpointAddress(address);
        }
        else 
{ // Unknown Port Name
            throw new javax.xml.rpc.ServiceException(" Cannot set Endpoint Address for Unknown Port" + portName);
        }
    }

    /**
    * Set the endpoint address for the specified port name.
    */
    public void setEndpointAddress(javax.xml.namespace.QName portName, java.lang.String address) throws javax.xml.rpc.ServiceException {
        setEndpointAddress(portName.getLocalPart(), address);
    }

}
